"""Independent verification of the Prompt 4.1.0 generation-only package ZIP.

Usage: python -I verify_generation_package.py <package_zip> <freeze_zip> <freeze_extract_dir> <empty_work_dir> [<zip_sha256_sidecar>]
Reads only the files in the ZIP and the freeze. Prints a JSON log of executed checks; exit code 1 if any check fails.
"""
import csv, hashlib, json, os, re, sys, zipfile

IDS = [f"HC{n:04d}" for n in range(1, 11)]
FIELDS = ["clinical_narrative_en", "clinical_narrative_es", "patient_explanation_en", "patient_explanation_es"]
CSV_MAP = {"clinical_records_english.csv": "clinical_narrative_en", "clinical_records_spanish.csv": "clinical_narrative_es",
           "patient_explanations_english.csv": "patient_explanation_en", "patient_explanations_spanish.csv": "patient_explanation_es"}
REQUIRED = ["clinical_narratives_bilingual_v9.json", "clinical_narratives_output_schema_v1.json", *CSV_MAP,
            "clinical_narratives_generation_qa_v9.json", "clinical_narratives_generation_report_v9.md",
            "clinical_narratives_generation_manifest_v9.json", "SHA256SUMS", "readme.txt"]
META = ["dataset_version", "source_schema_version", "source_dataset_sha256", "source_canonical_sha256", "source_freeze_sha256", "prompt_version",
        "generating_model_provider", "generating_model_identifier", "generating_model_version", "generation_timestamp_utc", "generation_parameters", "output_status"]


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def main(pkg, fz, fdir, work, side=None):
    from jsonschema import Draft202012Validator
    assert os.path.isdir(work) and not os.listdir(work), "work dir must exist and be empty"
    log = []
    chk = lambda name, ok, detail=None: log.append({"check": name, "passed": bool(ok), "detail": detail})
    with zipfile.ZipFile(pkg) as z:
        chk("zip_crc", z.testzip() is None)
        names = z.namelist()
        chk("zip_paths_safe", all(not n.startswith("/") and ".." not in n.split("/") for n in names))
        z.extractall(work)
    P = lambda f: os.path.join(work, f)
    chk("required_deliverables_present", all(os.path.exists(P(f)) for f in REQUIRED), [f for f in REQUIRED if not os.path.exists(P(f))])
    sums = dict(reversed(l.split("  ", 1)) for l in open(P("SHA256SUMS"), encoding="utf-8").read().splitlines())
    files = sorted(n for n in names if not n.endswith("/") and n != "SHA256SUMS")
    chk("sha256sums_cover_all_files", sorted(sums) == files, {"missing": sorted(set(files) - set(sums)), "extra": sorted(set(sums) - set(files))})
    chk("sha256sums_match", all(sha(P(f)) == h for f, h in sums.items()))
    if side:
        chk("zip_sidecar_match", open(side).read().split()[0] == sha(pkg), sha(pkg))
    doc = json.load(open(P("clinical_narratives_bilingual_v9.json"), encoding="utf-8"))
    schema = json.load(open(P("clinical_narratives_output_schema_v1.json"), encoding="utf-8"))
    chk("narratives_schema_valid", not list(Draft202012Validator(schema).iter_errors(doc)))
    gm = doc["generation_metadata"]
    chk("metadata_fields_and_values", list(gm) == META and gm["prompt_version"] == "4.1.0" and gm["dataset_version"] == 9
        and gm["source_schema_version"] == "1.2.1" and gm["output_status"] == "candidate_pending_review")
    chk("ten_patients_four_fields_non_empty", list(doc["records"]) == IDS and all(list(v) == FIELDS and all(t.strip() for t in v.values()) for v in doc["records"].values()))
    ok = {}
    for fn, fld in CSV_MAP.items():
        rows = list(csv.reader(open(P(fn), encoding="utf-8", newline="")))
        ok[fn] = rows[0] == ["id", "historia_clinica"] and [r[0] for r in rows[1:]] == IDS and all(len(r) == 2 for r in rows) \
            and all(rows[i + 1][1] == doc["records"][p][fld] for i, p in enumerate(IDS)) and not open(P(fn), "rb").read().startswith(b"\xef\xbb\xbf")
    chk("csv_exact_equality_with_json", all(ok.values()), ok)
    man = json.load(open(os.path.join(fdir, "clinical_reference_freeze_manifest.json"), encoding="utf-8"))
    ref = json.load(open(os.path.join(fdir, "clinical_records_reference.json"), encoding="utf-8"))
    canon = hashlib.sha256(json.dumps(ref, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
    chk("source_hashes", sha(fz) == gm["source_freeze_sha256"] and canon == gm["source_canonical_sha256"] == man["dataset_canonical_sha256"]
        and all(sha(os.path.join(fdir, f)) == h for f, h in man["file_checksums"].items()), {"freeze_zip": sha(fz), "canonical": canon})
    gman = json.load(open(P("clinical_narratives_generation_manifest_v9.json"), encoding="utf-8"))
    chk("manifest_output_checksums", all(sha(P(f)) == h for f, h in gman["output_files_sha256"].items()) and len(gman["output_files_sha256"]) == len(files) - 1)
    od = P("provenance/original_drafts")
    chk("original_drafts_hashes", {f: sha(os.path.join(od, f)) for f in sorted(os.listdir(od)) if f.endswith(".txt")} == gman["generation"]["original_drafts_sha256"])
    qa = json.load(open(P("clinical_narratives_generation_qa_v9.json"), encoding="utf-8"))
    chk("qa_no_prefilled_decisions", all(i["human_review_status"] == "pending_human_review" and i["reviewer"] is None and i["review_decision"] is None
                                          and i["review_date"] is None for i in qa["issues"]))
    chk("qa_bound_to_narratives", qa["report_metadata"]["narrative_file_sha256"] == sha(P("clinical_narratives_bilingual_v9.json"))
        and qa["report_metadata"]["issue_count"] == len(qa["issues"]))
    chk("no_model_weights_in_package", not any(n.endswith((".safetensors", ".bin", ".onnx", ".pt", ".gguf")) for n in names))
    chk("no_model_evaluation_outputs", not any(re.search(r"semantic|nli_|calibration|readability|hf_model", n) for n in names), [n for n in names if re.search(r"semantic|nli_|calibration|readability|hf_model", n)])
    tok = re.compile(r"hf_[A-Za-z0-9]{30,}|sk-ant-[A-Za-z0-9_-]{20,}")
    leaks = [n for n in names if not n.endswith("/") and tok.search(open(P(n), "rb").read().decode("utf-8", "ignore"))]
    chk("no_credentials_in_package", not leaks, leaks)
    out = {"package": os.path.basename(pkg), "package_sha256": sha(pkg), "checks": log, "all_passed": all(c["passed"] for c in log)}
    print(json.dumps(out, ensure_ascii=False, indent=1))
    return 0 if out["all_passed"] else 1


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:6]))
