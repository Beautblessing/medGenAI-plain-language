"""Prompt 4.1.0 (generation only): assemble, validate and screen the 40 narrative candidates.

Usage: python -I build_generation_package.py --freeze-zip <zip> --freeze-dir <extracted freeze>
          --original-dir <provenance/original_drafts> --revision-log <provenance/self_check_revisions_v9_prompt4_1.json>
          --revised-dir <empty dir for rebuilt final drafts> --out <package dir>

Steps: verify the freeze (Gate A); rebuild the final texts from the preserved original drafts by
applying the logged self-check revisions; assemble clinical_narratives_bilingual_v9.json; validate it
against clinical_narratives_output_schema_v1.json (Prompt 4.1.0 version); export the 4 CSVs and check
exact equality; run deterministic source-fidelity screening (no models); write the generation QA
report, manifest and report. No narrative text is written or changed by this script.
"""
import argparse, csv, datetime as dt, json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from narrative_eval import source, texts as T, factcheck as FC, inventory as INV  # noqa: E402
from narrative_eval.config import IDS, FIELDS, FIELD_TYPE, CSV_MAP  # noqa: E402
from narrative_eval.textcount import words  # noqa: E402
from jsonschema import Draft202012Validator  # noqa: E402

SCHEMA = {
 "$schema": "https://json-schema.org/draft/2020-12/schema",
 "$id": "https://example.invalid/schemas/track_a_prompt4_1_0/clinical_narratives_output_schema_v1.json",
 "title": "Track A bilingual clinical narrative output schema V1 (Prompt 4.1.0, generation only)",
 "description": ("Structure of clinical_narratives_bilingual_v9.json for Prompt 4.1.0: generation_metadata plus exactly ten records HC0001-HC0010, "
                 "each with exactly four non-empty narrative strings, and no other patients or fields. This file is specific to the Prompt 4.1.0 "
                 "generation package; it is not the same file as the Prompt 4.0 schema of the same name. Permitted nulls: source_freeze_sha256 "
                 "(only if no freeze ZIP was available), generating_model_provider/identifier/version (only if not known), generation_timestamp_utc "
                 "(only if not recorded). Individual generation_parameters values may be null when not exposed. Structural validity does not imply clinical approval."),
 "type": "object", "additionalProperties": False, "required": ["generation_metadata", "records"],
 "properties": {
  "generation_metadata": {
   "type": "object", "additionalProperties": False,
   "required": ["dataset_version", "source_schema_version", "source_dataset_sha256", "source_canonical_sha256", "source_freeze_sha256", "prompt_version",
                "generating_model_provider", "generating_model_identifier", "generating_model_version", "generation_timestamp_utc", "generation_parameters", "output_status"],
   "properties": {
    "dataset_version": {"const": 9}, "source_schema_version": {"const": "1.2.1"},
    "source_dataset_sha256": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
    "source_canonical_sha256": {"const": "08567e1be79e321263fb3d9b3a306d9b2c9a645e14898706d4accef2952b447e"},
    "source_freeze_sha256": {"type": ["string", "null"], "pattern": "^[0-9a-f]{64}$"},
    "prompt_version": {"const": "4.1.0"},
    "generating_model_provider": {"type": ["string", "null"], "minLength": 1},
    "generating_model_identifier": {"type": ["string", "null"], "minLength": 1},
    "generating_model_version": {"type": ["string", "null"], "minLength": 1},
    "generation_timestamp_utc": {"type": ["string", "null"], "pattern": "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?Z$"},
    "generation_parameters": {"type": "object"},
    "output_status": {"enum": ["candidate_pending_review", "human_review_in_progress", "human_reviewed"]}}},
  "records": {
   "type": "object", "additionalProperties": False, "minProperties": 10, "maxProperties": 10,
   "propertyNames": {"pattern": "^HC00(0[1-9]|10)$"},
   "required": IDS,
   "properties": {pid: {"type": "object", "additionalProperties": False, "required": FIELDS,
                        "properties": {f: {"type": "string", "minLength": 1, "pattern": "\\S"} for f in FIELDS}} for pid in IDS}}}}

GEN_TS = "2026-11-08T23:21:53Z"

PRIORITY = {"medication": "high", "unsupported_medication": "high", "diagnosis": "high", "certainty": "high", "warning": "high",
            "followup": "high", "qa_limitation": "high", "symptom": "standard", "progress": "high", "numeric": "high"}


def now():
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def main(a):
    os.makedirs(a.out, exist_ok=True)
    gate_a = source.verify_freeze(a.freeze_zip, a.freeze_dir)
    assert gate_a["passed"], gate_a
    ref = source.load_reference(a.freeze_dir)
    # rebuild final drafts from originals + logged revisions
    subprocess.run([sys.executable, "-I", os.path.join(HERE, "apply_self_check_revisions.py"), a.original_dir, a.revised_dir,
                    os.path.join(a.revised_dir, "_rebuild_log.json")], check=True, capture_output=True)
    log = json.load(open(a.revision_log, encoding="utf-8"))
    rebuilt = json.load(open(os.path.join(a.revised_dir, "_rebuild_log.json"), encoding="utf-8"))
    assert rebuilt["original_sha256"] == log["original_sha256"] and rebuilt["revised_sha256"] == log["revised_sha256"], "rebuild does not match the logged revision hashes"
    recs = {pid: T.parse_narrative_file(os.path.join(a.revised_dir, pid + ".txt")) for pid in IDS}
    gen_ts = GEN_TS  # time the original drafts were frozen (ORIGINALS_SHA256SUMS written in the generation session)
    doc = {"generation_metadata": {
        "dataset_version": 9, "source_schema_version": "1.2.1", "source_dataset_sha256": gate_a["dataset_file_sha256"],
        "source_canonical_sha256": gate_a["canonical_sha256"], "source_freeze_sha256": gate_a["freeze_zip_sha256"], "prompt_version": "4.1.0",
        "generating_model_provider": "Anthropic", "generating_model_identifier": "claude-opus-5-5", "generating_model_version": None,
        "generation_timestamp_utc": gen_ts,
        "generation_parameters": {
            "generation_mode": "Interactive authoring by one AI model in one Claude Code session: each text written directly from the approved record and its fact inventory; no template or deterministic assembly; no separate sampling API call",
            "model_identifier_note": "Identifier of the model configured for the session; the serving snapshot is not exposed and is not independently verified. All 40 texts come from this one session.",
            "temperature": None, "top_p": None, "top_k": None, "max_output_tokens": None, "seed": None,
            "parameter_note": "Sampling parameters are not exposed to the session and are recorded as null.",
            "executed_prompt": "Combined Master Prompt 4.1 (generation + evaluation), whose generation requirements match Prompt 4.1.0; repackaged under Prompt 4.1.0 (generation only) at the user's request without regeneration",
            "draft_order": "per patient: EN professional, ES professional, EN patient, ES patient; then source-based self-check",
            "final_version": "originals in provenance/original_drafts + 17 logged self-check revisions (provenance/self_check_revisions_v9_prompt4_1.json); the records below are the corrected final versions",
            "model_based_evaluation": "none in this package"},
        "output_status": "candidate_pending_review"}, "records": recs}
    nj = os.path.join(a.out, "clinical_narratives_bilingual_v9.json")
    json.dump(doc, open(nj, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    sp = os.path.join(a.out, "clinical_narratives_output_schema_v1.json")
    json.dump(SCHEMA, open(sp, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    Draft202012Validator.check_schema(SCHEMA)
    reload = json.load(open(nj, encoding="utf-8"))
    serr = [e.message for e in Draft202012Validator(json.load(open(sp, encoding="utf-8"))).iter_errors(reload)]
    # CSVs
    csvc = {}
    for fn, fld in CSV_MAP.items():
        p = os.path.join(a.out, fn)
        with open(p, "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f, lineterminator="\n"); w.writerow(["id", "historia_clinica"])
            for pid in IDS:
                w.writerow([pid, reload["records"][pid][fld]])
        rows = list(csv.reader(open(p, encoding="utf-8", newline="")))
        csvc[fn] = {"header": rows[0] == ["id", "historia_clinica"], "ten_rows_in_order": [r[0] for r in rows[1:]] == IDS,
                    "exact_equality": all(rows[i + 1][1] == reload["records"][pid][fld] for i, pid in enumerate(IDS)),
                    "two_columns": all(len(r) == 2 for r in rows), "utf8_no_bom": not open(p, "rb").read().startswith(b"\xef\xbb\xbf")}
    # deterministic screening
    fs = FC.Findings()
    for pid in IDS:
        FC.run_layer_c(pid, ref[pid], reload["records"][pid], fs)
        FC.bilingual_parity(pid, reload["records"][pid], fs)
    inv = [f for pid in IDS for f in INV.build_inventory(pid, ref[pid])]
    os.makedirs(os.path.join(a.out, "provenance"), exist_ok=True)
    json.dump({"note": "Fact inventory (generation step 2): facts rendered from the approved record with JSON paths and epistemic tags (positive, negative, unknown, planned, pending, prescribed, administered).",
               "facts": inv}, open(os.path.join(a.out, "provenance", "clinical_fact_inventory_v9.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(fs.items, open(os.path.join(a.out, "provenance", "source_fidelity_screening_findings_v9.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    cats = {}
    fam = {}
    for i in fs.items:
        cats[i["category"]] = cats.get(i["category"], 0) + 1
        k = i["check_family"]; fam.setdefault(k, {}); fam[k][i["category"]] = fam[k].get(i["category"], 0) + 1
    wc = {pid: {f: len(words(T.sections(reload["records"][pid][f], f) and "\n".join(T.sections(reload["records"][pid][f], f).values()))) for f in FIELDS} for pid in IDS}
    # generation QA
    issues = []

    def add(pid, fields, concern, ref_path, src, gen, prio, action, origin, status="pending_human_review", resolution=None):
        issues.append({"issue_id": f"GQA41-V9-{len(issues)+1:03d}", "patient_id": pid, "narrative_field": fields, "clinical_concern": concern,
                       "supporting_source_reference": ref_path, "source_evidence": src, "generated_text_evidence": gen, "review_priority": prio,
                       "proposed_review_action": action, "origin": origin, "generation_resolution": resolution, "human_review_status": status,
                       "reviewer": None, "review_decision": None, "review_date": None})
    for r in log["revisions"]:
        add(r["patient_id"], [r["field"]], f"Self-check correction {r['revision_id']}: {r['rationale']}", r["source_path"], None,
            f"original: {r['original_text']} | final: {r['revised_text']}", "high" if any(k in r["source_path"] for k in ("medication", "follow_up", "diagnosis")) else "standard",
            "Confirm that the final wording is faithful to the source.", "generation_self_check", resolution="corrected in final version; original preserved")
    for c in log["considered_without_change"]:
        add(c["patient_id"], [f for f in FIELDS if f.startswith(c["field"].split("/")[0].rsplit("_", 1)[0])], c["note"], c["source_path"], None, None, "standard",
            "Decide whether a change is needed.", "generation_self_check", resolution="no change made")
    for i in fs.items:
        if i["category"] == "supported":
            continue
        add(i["patient_id"], [x for x in i["narrative_field"].split("|") if x in FIELDS],
            f"Deterministic screen: {i['category']} ({i['check_family']}/{i['check_id']}): {i['source_fact_or_evidence']}", i["source_json_path"],
            i["source_fact_or_evidence"], i["generated_claim_or_sentence"], PRIORITY.get(i["check_family"], "standard"),
            "Check the text against the source path; confirm or dismiss the automated flag.", "deterministic_screening")
    for pid in IDS:
        out_rng = {f: wc[pid][f] for f in ("clinical_narrative_en", "clinical_narrative_es") if not 300 <= wc[pid][f] <= 450}
        if out_rng:
            add(pid, list(out_rng), f"Length outside the prompt's preferred ~300-450 words per professional narrative (words excluding headings): {out_rng}. Spanish runs longer than English for the same content.",
                f"/{pid}", None, None, "standard", "Confirm the length is acceptable or ask for condensing/expansion.", "generation_self_check")
    add("HC0010", ["clinical_narrative_es", "patient_explanation_es"], "Bilingual naming: Spanish texts use 'ácido acetilsalicílico' where English uses 'aspirin'. Equivalent; confirm preferred local naming.",
        "/HC0010/medication_management/medications/0/name", "Aspirin", "ácido acetilsalicílico 100 mg", "standard", "Confirm naming.", "bilingual_review")
    add(None, [], "Clinical-note English headings are 'Assessment and diagnosis' and 'Treatment and clinical course' rather than Prompt 4.1.0's 'Clinical Assessment and Diagnosis' and 'Treatment and Clinical Progress' (the prompt allows adaptation). Texts were written under the combined 4.1 prompt.",
        None, None, None, "standard", "Accept or request heading change.", "generation_self_check")
    qa = {"report_metadata": {"prompt_version": "4.1.0", "dataset_version": 9, "source_canonical_sha256": gate_a["canonical_sha256"],
                              "narrative_file_sha256": source.sha256_file(nj), "created_utc": now(), "issue_count": len(issues),
                              "note": "Generation-stage issues only. The historical clinical_reference_qa_issues.json is not modified. No reviewer, approval or decision is recorded."},
          "historical_qa_limitations_preserved": {
              q: {"patient": L["patient"], "statement": L["statement"],
                  "fields_passing_wording_check": [i["narrative_field"] for i in fs.items if i["check_id"] == q and i["category"] == "supported"],
                  "fields_failing": [i["narrative_field"] for i in fs.items if i["check_id"] == q and i["category"] != "supported"]}
              for q, L in __import__("narrative_eval.catalog", fromlist=["LIMITATIONS"]).LIMITATIONS.items()},
          "issues": issues}
    json.dump(qa, open(os.path.join(a.out, "clinical_narratives_generation_qa_v9.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    checks = [
        ("Exactly ten source patients", gate_a["exact_patient_set"], "freeze record keys == HC0001-HC0010"),
        ("Source integrity (ZIP, manifest checksums, canonical hash, 13 sections)", gate_a["passed"], "executed"),
        ("Exactly forty generated texts, four fields per patient, non-empty", sum(len(v) for v in recs.values()) == 40 and all(list(v) == FIELDS and all(t.strip() for t in v.values()) for v in recs.values()), "executed"),
        ("Valid output JSON against clinical_narratives_output_schema_v1.json", not serr, "; ".join(serr) or "executed"),
        ("CSV structure, order, UTF-8, exact equality with JSON", all(all(c.values()) for c in csvc.values()), "executed"),
        ("No invented patient IDs", not (set(re.findall(r"HC\d{4}", " ".join(t for v in recs.values() for t in v.values()))) - set(IDS)), "regex HC#### over all texts"),
        ("Final texts rebuilt from originals + logged revisions match logged hashes", True, "executed"),
    ]
    screen_rows = [(k, v) for k, v in sorted(fam.items())]
    man = {"manifest_version": "4.1.0-generation", "created_utc": now(),
           "source": {"freeze_zip_filename": "freeze_20261106T152049729544Z_v0009_08567e1be79e_approved.zip", "freeze_zip_sha256": gate_a["freeze_zip_sha256"],
                      "reference_dataset_sha256": gate_a["dataset_file_sha256"], "canonical_dataset_sha256": gate_a["canonical_sha256"], "source_schema_version": "1.2.1",
                      "freeze_file_checksums_verified": gate_a["manifest_file_checksums_ok"]},
           "prompt_version": "4.1.0", "generation": {"model_provider": "Anthropic", "model_identifier": "claude-opus-5-5", "model_version": None,
                      "model_configuration_used": doc["generation_metadata"]["generation_parameters"], "per_record_provenance": {pid: "same session and model as all records" for pid in IDS},
                      "generation_timestamp_utc": gen_ts, "execution_date": gen_ts[:10], "raw_outputs": "provenance/original_drafts/ (the model's first drafts, unchanged)",
                      "original_drafts_sha256": rebuilt["original_sha256"], "final_texts_sha256": rebuilt["revised_sha256"],
                      "executed_prompt": "provenance/executed_prompt_master_4_1_combined.txt", "governing_prompt": "provenance/governing_prompt_4_1_0_generation_only.txt"},
           "records": 10, "generated_texts": 40, "narrative_review_status": "candidate_pending_review (no human review recorded)",
           "word_counts_excluding_headings": wc, "output_files_sha256": {}}
    jm = os.path.join(a.out, "clinical_narratives_generation_manifest_v9.json")
    # report
    R = ["# Track A, Prompt 4.1.0 (generation only): V9 bilingual narrative candidates\n",
         "**Status:** 40 narrative candidates generated, validated and screened; pending independent clinical and bilingual review (Gate E open).\n",
         "This package contains no model-based evaluation. The earlier combined Prompt 4.1 evaluation package is kept unchanged as a separate artifact.\n",
         "## Source integrity (Gate A)", f"- Freeze ZIP SHA-256: {gate_a['freeze_zip_sha256']}", f"- Reference dataset file SHA-256: {gate_a['dataset_file_sha256']}",
         f"- Canonical dataset SHA-256: {gate_a['canonical_sha256']} (matches expected: {gate_a['canonical_matches_expected']})",
         f"- Freeze manifest checksums: {sum(gate_a['manifest_file_checksums_ok'].values())}/{len(gate_a['manifest_file_checksums_ok'])} match; patients {len(gate_a['patient_ids'])}; 13 sections each: {gate_a['thirteen_sections_each']}\n",
         "## Generation (Gate B)", "- Patients processed: 10", "- English clinical narratives: 10", "- Spanish clinical narratives: 10",
         "- English patient explanations: 10", "- Spanish patient explanations: 10",
         f"- Original drafts preserved in provenance/original_drafts; {len(log['revisions'])} self-check corrections applied and logged; the JSON and CSVs hold the corrected final versions.",
         "- Author: one AI model (Anthropic, session model claude-opus-5-5) writing directly from the record; snapshot and sampling parameters not exposed (null).",
         "- Texts were written under the combined Master Prompt 4.1, whose generation requirements are the same as Prompt 4.1.0, and repackaged here without regeneration.\n",
         "Word counts excluding headings (prompt prefers about 300-450 per professional narrative; out-of-range notes are QA items):\n", "| Patient | EN clinical | ES clinical | EN patient | ES patient |", "|---|---|---|---|---|"]
    R += [f"| {pid} | " + " | ".join(str(wc[pid][f]) for f in FIELDS) + " |" for pid in IDS]
    R += ["\n## Technical validation (Gate C) and executed checks", "| Check | Result | Note |", "|---|---|---|"]
    R += [f"| {n} | {'pass' if ok else 'FAIL'} | {note} |" for n, ok, note in checks]
    R += ["\n## Clinical fact screening (Gate D, deterministic, no models)",
          "Lexical checks against the record: diagnoses and certainty, medication names/doses/routes/frequencies/durations, administered vs prescribed, investigations and statuses, documented negatives, numbers and dates, warnings and urgency, follow-up intervals and booking status, progress, QA-005/010/011 wording, EN/ES number parity.\n",
          f"Totals: {cats}\n", "| Check family | Results |", "|---|---|"]
    R += [f"| {k} | {v} |" for k, v in screen_rows]
    nonsup = [i for i in fs.items if i["category"] != "supported"]
    bil = [i for i in fs.items if i["check_id"] == "bilingual_numbers"]
    bil_ok = sum(i["category"] == "supported" for i in bil)
    R += ["\nNon-supported screening results (each is a QA item):\n", "| Patient | Field | Category | Check | Evidence |", "|---|---|---|---|---|"]
    R += [f"| {i['patient_id']} | {i['narrative_field']} | {i['category']} | {i['check_family']}/{i['check_id']} | {str(i['source_fact_or_evidence'])[:120]} |" for i in nonsup] or ["| - | - | none | - | - |"]
    R += ["", "## Bilingual review findings", f"- EN and ES number sets identical in {bil_ok}/{len(bil)} language pairs (numeric parity screen).",
          "- HC0010 Spanish uses 'ácido acetilsalicílico' for aspirin (equivalent; naming to confirm).",
          "- Full semantic equivalence was not assessed by a model in this package and still needs a bilingual reviewer.\n",
          f"## Outstanding human-review items\n{len(issues)} items in clinical_narratives_generation_qa_v9.json, all pending. No reviewer, approval or decision is recorded.\n",
          "## Limitations", "- Screening is lexical; it cannot establish clinical accuracy. Its patterns were written by the same model that wrote the texts, so blind spots may be shared.",
          "- Structural validity does not imply clinical approval.", "- Model snapshot and sampling parameters are not exposed and are recorded as null.\n",
          "## Reproducibility\nSee readme.txt. Re-run with scripts/build_generation_package.py; verify with scripts/verify_generation_package.py.\n"]
    open(os.path.join(a.out, "clinical_narratives_generation_report_v9.md"), "w", encoding="utf-8").write("\n".join(R))
    excl = {"SHA256SUMS", "clinical_narratives_generation_manifest_v9.json"}
    allf = sorted(os.path.relpath(os.path.join(d, f), a.out) for d, _, fsn in os.walk(a.out) for f in fsn if f not in excl and "__pycache__" not in d)
    man["output_files_sha256"] = {f: source.sha256_file(os.path.join(a.out, f)) for f in allf}
    json.dump(man, open(jm, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    allf = sorted(os.path.relpath(os.path.join(d, f), a.out) for d, _, fsn in os.walk(a.out) for f in fsn if f != "SHA256SUMS" and "__pycache__" not in d)
    open(os.path.join(a.out, "SHA256SUMS"), "w", encoding="utf-8").write("".join(f"{source.sha256_file(os.path.join(a.out, f))}  {f}\n" for f in allf))
    print(json.dumps({"schema_errors": serr, "csv": csvc, "screen": cats, "issues": len(issues), "checks": [(n, ok) for n, ok, _ in checks]}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    for k in ["freeze-zip", "freeze-dir", "original-dir", "revision-log", "revised-dir", "out"]:
        ap.add_argument("--" + k, required=True)
    main(ap.parse_args())
