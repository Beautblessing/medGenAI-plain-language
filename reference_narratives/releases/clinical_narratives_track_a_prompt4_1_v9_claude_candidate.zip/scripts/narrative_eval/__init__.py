"""narrative_eval (generation-package subset): source verification, parsing, fact inventory and
deterministic source-fidelity screening. No model-based evaluation is included here."""
__version__ = "4.1.0"
