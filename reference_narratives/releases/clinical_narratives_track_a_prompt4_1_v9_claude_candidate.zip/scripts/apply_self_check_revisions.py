"""Apply the generation-stage self-check revisions to copies of the original drafts.

Originals in original/ are never modified (read-only, hashed in ORIGINALS_SHA256SUMS).
Every revision below was decided during the self-check step of generation, BEFORE any
automated evaluation (Layers A-D) was run. Each edit is an exact, unique string
replacement with a rationale and the source path that motivated it.
Usage: python -I apply_self_check_revisions.py <original_dir> <revised_dir> <log_json>
"""
import hashlib, json, os, shutil, sys

REVISIONS = [
 ("HC0001", "patient_explanation_en", "It can be treated at home with antibiotic tablets or liquid by mouth.",
  "It can be treated at home with an antibiotic taken by mouth.",
  "Tablet or liquid form is not documented; keep only the documented oral route.", "/HC0001/medication_management/medications/0/route"),
 ("HC0003", "patient_explanation_en", "There were no ketones in your urine, which are a sign of a more dangerous sugar problem.",
  "There were no ketones in your urine.",
  "Explanatory claim about ketones is not stated in the record; removed as unsupported addition.", "/HC0003/clinical_examination_and_investigations/laboratory_tests"),
 ("HC0003", "patient_explanation_es", "No había cetonas en la orina, que son una señal de un problema de azúcar más peligroso.",
  "No había cetonas en la orina.",
  "Same unsupported gloss as the English text.", "/HC0003/clinical_examination_and_investigations/laboratory_tests"),
 ("HC0003", "patient_explanation_en", "You will also be referred to the eye clinic for the diabetes eye check when a place is available.",
  "A referral to the eye clinic for the diabetes eye check is also planned, when a place is available.",
  "Referral status is 'planned'; future-tense certainty wording replaced by planned status.", "/HC0003/follow_up_and_monitoring_plan/follow_up_items/2/status"),
 ("HC0003", "patient_explanation_es", "También se la derivará a oftalmología para la revisión de los ojos cuando haya plaza.",
  "También está prevista una derivación a oftalmología para la revisión de los ojos cuando haya plaza.",
  "Same lifecycle correction as the English text.", "/HC0003/follow_up_and_monitoring_plan/follow_up_items/2/status"),
 ("HC0004", "clinical_narrative_en", "No surgical history or drug allergies documented.",
  "No surgical history or allergies documented.",
  "The record has an empty allergy list, not specifically 'drug' allergies.", "/HC0004/relevant_medical_history/allergies"),
 ("HC0004", "clinical_narrative_es", "No constan antecedentes quirúrgicos ni alergias medicamentosas.",
  "No constan antecedentes quirúrgicos ni alergias.",
  "Same correction as the English text.", "/HC0004/relevant_medical_history/allergies"),
 ("HC0005", "patient_explanation_en", "Being overweight and taking ibuprofen now and then may make reflux worse.",
  "Being overweight and taking ibuprofen now and then may be contributing to your reflux.",
  "Source says 'may be contributing'; 'make worse' shifts the causal claim.", "/HC0005/clinical_assessment_and_diagnosis/clinical_assessment"),
 ("HC0005", "patient_explanation_es", "El sobrepeso y tomar ibuprofeno de vez en cuando pueden empeorar el reflujo.",
  "El sobrepeso y tomar ibuprofeno de vez en cuando pueden estar contribuyendo al reflujo.",
  "Same correction as the English text.", "/HC0005/clinical_assessment_and_diagnosis/clinical_assessment"),
 ("HC0008", "patient_explanation_en", "and we heard a soft heart murmur of the kind that can happen with anaemia.",
  "and we heard a soft heart murmur.",
  "Link between murmur and anaemia is not stated in the record.", "/HC0008/clinical_examination_and_investigations/physical_examination/1"),
 ("HC0008", "patient_explanation_es", "y se oyó un soplo suave en el corazón, de los que pueden aparecer con la anemia.",
  "y se oyó un soplo suave en el corazón.",
  "Same correction as the English text.", "/HC0008/clinical_examination_and_investigations/physical_examination/1"),
 ("HC0008", "patient_explanation_en", "foods and drinks with calcium can stop the iron being absorbed.",
  "foods and drinks with calcium can reduce how much iron you absorb.",
  "Source says absorption 'may be reduced'; 'stop' overstates.", "/HC0008/medication_management/medications/0/dose_instruction/additional_instructions"),
 ("HC0008", "patient_explanation_es", "los alimentos y bebidas con calcio pueden impedir que se absorba el hierro.",
  "los alimentos y bebidas con calcio pueden reducir la absorción del hierro.",
  "Same correction as the English text.", "/HC0008/medication_management/medications/0/dose_instruction/additional_instructions"),
 ("HC0009", "patient_explanation_en", "Cancer treatment has not started yet.",
  "Your hoarseness has not changed since the biopsy. Cancer treatment has not started yet.",
  "Documented progress (hoarseness unchanged since biopsy) was omitted from the patient text.", "/HC0009/clinical_progress/clinical_course"),
 ("HC0009", "patient_explanation_es", "El tratamiento del cáncer todavía no ha empezado.",
  "La ronquera no ha cambiado desde la biopsia. El tratamiento del cáncer todavía no ha empezado.",
  "Same omission as the English text.", "/HC0009/clinical_progress/clinical_course"),
 ("HC0010", "patient_explanation_en", "An X-ray test of the heart arteries (coronary angiography)",
  "A test that takes pictures of the heart arteries (coronary angiography)",
  "Imaging modality detail (X-ray) is not stated in the record.", "/HC0010/clinical_examination_and_investigations/imaging_studies/0/modality"),
 ("HC0010", "patient_explanation_es", "Una prueba de rayos X de las arterias del corazón (coronariografía)",
  "Una prueba que obtiene imágenes de las arterias del corazón (coronariografía)",
  "Same correction as the English text.", "/HC0010/clinical_examination_and_investigations/imaging_studies/0/modality"),
]
CONSIDERED_NO_CHANGE = [
 ("HC0003", "patient_explanation_en/es", "Atorvastatin purpose gloss ('lowers cholesterol to protect your heart and blood vessels') kept: the record documents lipid-lowering therapy for cardiovascular risk reduction in diabetes.", "/HC0003/medication_management/medications/1/indication"),
 ("HC0004", "patient_explanation_en/es", "Historical salbutamol dose (100 micrograms, 2 inhalations) not added to the patient texts: the medicine is stopped and the patient texts state that clearly. Left for human review.", "/HC0004/medication_management/medications"),
]


def parse(path):
    out, cur = {}, None
    for line in open(path, encoding="utf-8").read().split("\n"):
        if line.startswith("@@"):
            cur = line[2:].strip(); out[cur] = []
        elif cur:
            out[cur].append(line)
    return {k: "\n".join(v).strip("\n") for k, v in out.items()}


def dump(d, path):
    with open(path, "w", encoding="utf-8") as f:
        for k in ["clinical_narrative_en", "clinical_narrative_es", "patient_explanation_en", "patient_explanation_es"]:
            f.write("@@" + k + "\n" + d[k] + "\n")


def main(src, dst, log):
    os.makedirs(dst, exist_ok=True)
    assert not [f for f in os.listdir(dst) if f.endswith(".txt")], "revised dir must start empty"
    docs = {f[:6]: parse(os.path.join(src, f)) for f in sorted(os.listdir(src)) if f.endswith(".txt")}
    entries = []
    for i, (pid, field, old, new, why, path) in enumerate(REVISIONS, 1):
        t = docs[pid][field]
        assert t.count(old) == 1, (pid, field, old)
        docs[pid][field] = t.replace(old, new)
        entries.append({"revision_id": f"R41-{i:03d}", "patient_id": pid, "field": field, "original_text": old, "revised_text": new,
                        "rationale": why, "source_path": path, "stage": "generation self-check, before automated evaluation"})
    for pid, d in docs.items():
        dump(d, os.path.join(dst, pid + ".txt"))
    sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
    json.dump({"revisions": entries,
               "considered_without_change": [{"patient_id": a, "field": b, "note": c, "source_path": d} for a, b, c, d in CONSIDERED_NO_CHANGE],
               "original_sha256": {f: sha(os.path.join(src, f)) for f in sorted(os.listdir(src)) if f.endswith(".txt")},
               "revised_sha256": {f: sha(os.path.join(dst, f)) for f in sorted(os.listdir(dst)) if f.endswith(".txt")}},
              open(log, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(len(entries), "revisions applied")


if __name__ == "__main__":
    main(*sys.argv[1:4])
