TRACK A - PROMPT 4.1.0 - NARRATIVE GENERATION ONLY - V9 BILINGUAL NARRATIVE CANDIDATES
=====================================================================================

Status: candidate_pending_review. Gates A-D executed; Gate E (independent clinical and bilingual
review) is open. No reviewer, approval or decision is recorded. Passing Gates A-D does not mean Gate E.
This package does not touch the 20-case Track B project and does not modify the approved V9 freeze.

Which version is final
----------------------
FINAL: clinical_narratives_bilingual_v9.json and the four CSVs (identical text). These are the
corrected final versions.
ORIGINAL DRAFTS: provenance/original_drafts/HC0001-HC0010.txt are the model's first drafts, unchanged.
CORRECTIONS: provenance/self_check_revisions_v9_prompt4_1.json logs the 17 self-check corrections
(original text, final text, rationale, source path) applied to the drafts to give the final versions,
plus 2 points considered and left unchanged. Every correction is also a QA item for review.

Deliverables (Prompt 4.1.0, section 18)
---------------------------------------
clinical_narratives_bilingual_v9.json        40 texts (HC0001-HC0010 x 4 fields) + generation_metadata
clinical_narratives_output_schema_v1.json    schema for this package (Prompt 4.1.0; not the same file as
                                             the Prompt 4.0 schema of the same name)
clinical_records_english.csv                 id,historia_clinica  (clinical_narrative_en)
clinical_records_spanish.csv                 id,historia_clinica  (clinical_narrative_es)
patient_explanations_english.csv             id,historia_clinica  (patient_explanation_en)
patient_explanations_spanish.csv             id,historia_clinica  (patient_explanation_es)
clinical_narratives_generation_qa_v9.json    generation-stage issues, all pending human review
clinical_narratives_generation_report_v9.md  gates, counts, validation, screening, open items
clinical_narratives_generation_manifest_v9.json  source/prompt/model provenance, output checksums
SHA256SUMS                                   SHA-256 of every other file in the package
readme.txt                                   this file
Supporting: provenance/ (original drafts, revision log, fact inventory, deterministic screening
findings, style-reference inventory, executed and governing prompts) and scripts/.

How the narratives were produced
--------------------------------
Written by an AI model (Anthropic, configured session model claude-opus-5-5) in one interactive Claude
Code session, directly from the approved ten-case record (style references used for register only; no
web, other dataset or Track B content). Not template assembly. Model snapshot and sampling parameters
are not exposed and are recorded as null. The texts were written under the combined Master Prompt 4.1
(generation + evaluation), whose generation requirements match Prompt 4.1.0, and were repackaged here
without regeneration. No model-based evaluation (readability, semantic similarity, NLI) is in this
package; the earlier combined 4.1 evaluation package is a separate artifact and was not changed.

Reproducing the package
-----------------------
Run Python with -I and extract each ZIP into its own empty directory.
1. Freeze: freeze_20261106T152049729544Z_v0009_08567e1be79e_approved.zip, SHA-256
   11643597900d00351770f44f358264dab6c181ba3c67cc7811b7cbc26e4d8f0f. Extract into empty dir FREEZE.
   Canonical dataset SHA-256 08567e1be79e321263fb3d9b3a306d9b2c9a645e14898706d4accef2952b447e
   (json.dumps sort_keys=True, separators=(',',':'), ensure_ascii=False, UTF-8).
2. pip install -r scripts/requirements.txt (Python 3.13). No model download, no network, no token.
3. Rebuild, validate, export and screen:
   python -I -B scripts/build_generation_package.py --freeze-zip <zip> --freeze-dir FREEZE
     --original-dir provenance/original_drafts --revision-log provenance/self_check_revisions_v9_prompt4_1.json
     --revised-dir <empty dir> --out <empty output dir>
   It verifies the freeze and stops on any mismatch, rebuilds the final texts from the original drafts
   plus the logged corrections (hashes must match the log), writes the JSON, validates it against the
   schema, exports the 4 CSVs (UTF-8, no BOM, header id,historia_clinica, HC0001-HC0010 order) and checks
   exact equality, runs the deterministic screen and writes the QA file, report, manifest and SHA256SUMS.
   Timestamps in the QA file and manifest will differ; narrative text and CSVs are byte-identical.
4. Verify a package: python -I scripts/verify_generation_package.py <package zip> <freeze zip> FREEZE <empty dir>
5. Human review: record reviewer, decision and date per item in clinical_narratives_generation_qa_v9.json
   (null now). Only a real reviewer may fill them.

Credentials: none are needed or stored. If any API key is ever used, keep it in the environment, never
in this package or the repository. No model weights are included.

Limitations
-----------
- The screen is lexical; it cannot establish clinical accuracy. Its patterns and the texts were
  written by the same model, so they may share blind spots.
- Structural validity does not imply clinical approval.
