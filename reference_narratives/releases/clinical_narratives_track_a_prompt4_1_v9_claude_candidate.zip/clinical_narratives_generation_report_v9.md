# Track A, Prompt 4.1.0 (generation only): V9 bilingual narrative candidates

**Status:** 40 narrative candidates generated, validated and screened; pending independent clinical and bilingual review (Gate E open).

This package contains no model-based evaluation. The earlier combined Prompt 4.1 evaluation package is kept unchanged as a separate artifact.

## Source integrity (Gate A)
- Freeze ZIP SHA-256: 11643597900d00351770f44f358264dab6c181ba3c67cc7811b7cbc26e4d8f0f
- Reference dataset file SHA-256: 710fdb5e4373f5d16ccbf64ddc6b3207b16ebefc0cdaf5ac9b1820e1a9c7806a
- Canonical dataset SHA-256: 08567e1be79e321263fb3d9b3a306d9b2c9a645e14898706d4accef2952b447e (matches expected: True)
- Freeze manifest checksums: 9/9 match; patients 10; 13 sections each: True

## Generation (Gate B)
- Patients processed: 10
- English clinical narratives: 10
- Spanish clinical narratives: 10
- English patient explanations: 10
- Spanish patient explanations: 10
- Original drafts preserved in provenance/original_drafts; 17 self-check corrections applied and logged; the JSON and CSVs hold the corrected final versions.
- Author: one AI model (Anthropic, session model claude-opus-5-5) writing directly from the record; snapshot and sampling parameters not exposed (null).
- Texts were written under the combined Master Prompt 4.1, whose generation requirements are the same as Prompt 4.1.0, and repackaged here without regeneration.

Word counts excluding headings (prompt prefers about 300-450 per professional narrative; out-of-range notes are QA items):

| Patient | EN clinical | ES clinical | EN patient | ES patient |
|---|---|---|---|---|
| HC0001 | 344 | 385 | 314 | 317 |
| HC0002 | 372 | 439 | 344 | 381 |
| HC0003 | 400 | 442 | 386 | 420 |
| HC0004 | 407 | 481 | 394 | 440 |
| HC0005 | 359 | 409 | 370 | 402 |
| HC0006 | 301 | 343 | 291 | 304 |
| HC0007 | 279 | 313 | 238 | 241 |
| HC0008 | 388 | 430 | 368 | 373 |
| HC0009 | 399 | 460 | 372 | 380 |
| HC0010 | 510 | 603 | 508 | 530 |

## Technical validation (Gate C) and executed checks
| Check | Result | Note |
|---|---|---|
| Exactly ten source patients | pass | freeze record keys == HC0001-HC0010 |
| Source integrity (ZIP, manifest checksums, canonical hash, 13 sections) | pass | executed |
| Exactly forty generated texts, four fields per patient, non-empty | pass | executed |
| Valid output JSON against clinical_narratives_output_schema_v1.json | pass | executed |
| CSV structure, order, UTF-8, exact equality with JSON | pass | executed |
| No invented patient IDs | pass | regex HC#### over all texts |
| Final texts rebuilt from originals + logged revisions match logged hashes | pass | executed |

## Clinical fact screening (Gate D, deterministic, no models)
Lexical checks against the record: diagnoses and certainty, medication names/doses/routes/frequencies/durations, administered vs prescribed, investigations and statuses, documented negatives, numbers and dates, warnings and urgency, follow-up intervals and booking status, progress, QA-005/010/011 wording, EN/ES number parity.

Totals: {'supported': 986, 'requires_human_review': 10, 'omission': 2}

| Check family | Results |
|---|---|
| bilingual | {'supported': 20} |
| certainty | {'supported': 50} |
| diagnosis | {'supported': 68} |
| followup | {'supported': 100} |
| history | {'supported': 10} |
| identity | {'supported': 180} |
| investigation | {'supported': 54} |
| medication | {'supported': 186, 'omission': 2} |
| numeric | {'supported': 92} |
| procedure | {'supported': 16} |
| progress | {'supported': 28} |
| qa_limitation | {'supported': 12} |
| symptom | {'supported': 82, 'requires_human_review': 10} |
| warning | {'supported': 88} |

Non-supported screening results (each is a QA item):

| Patient | Field | Category | Check | Evidence |
|---|---|---|---|---|
| HC0001 | patient_explanation_en | requires_human_review | symptom/neg | No cough |
| HC0001 | patient_explanation_es | requires_human_review | symptom/neg | No cough |
| HC0001 | patient_explanation_en | requires_human_review | symptom/neg | No nasal congestion |
| HC0001 | patient_explanation_es | requires_human_review | symptom/neg | No nasal congestion |
| HC0001 | patient_explanation_en | requires_human_review | symptom/neg | No ear pain |
| HC0001 | patient_explanation_es | requires_human_review | symptom/neg | No ear pain |
| HC0003 | patient_explanation_en | omission | medication/met | Metformin 500 mg | source value: 500 mg |
| HC0003 | patient_explanation_es | omission | medication/met | Metformin 500 mg | source value: 500 mg |
| HC0003 | patient_explanation_en | requires_human_review | symptom/neg | No weight loss |
| HC0003 | patient_explanation_es | requires_human_review | symptom/neg | No weight loss |
| HC0003 | patient_explanation_en | requires_human_review | symptom/neg | No blurred vision |
| HC0003 | patient_explanation_es | requires_human_review | symptom/neg | No blurred vision |

## Bilingual review findings
- EN and ES number sets identical in 20/20 language pairs (numeric parity screen).
- HC0010 Spanish uses 'ácido acetilsalicílico' for aspirin (equivalent; naming to confirm).
- Full semantic equivalence was not assessed by a model in this package and still needs a bilingual reviewer.

## Outstanding human-review items
37 items in clinical_narratives_generation_qa_v9.json, all pending. No reviewer, approval or decision is recorded.

## Limitations
- Screening is lexical; it cannot establish clinical accuracy. Its patterns were written by the same model that wrote the texts, so blind spots may be shared.
- Structural validity does not imply clinical approval.
- Model snapshot and sampling parameters are not exposed and are recorded as null.

## Reproducibility
See readme.txt. Re-run with scripts/build_generation_package.py; verify with scripts/verify_generation_package.py.
